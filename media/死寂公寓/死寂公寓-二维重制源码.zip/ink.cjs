"use strict";

const { createCanvas, Path2D } = require("@napi-rs/canvas");
const clamp = (v, a = 0, b = 1) => Math.max(a, Math.min(b, v));
const mix = (a, b, u) => a + (b - a) * u;
function ramp(t, start, end) {
  const u = clamp((t - start) / (end - start));
  return u * u * (3 - 2 * u);
}
function impulse(t, start, amplitude, hz = 8, decay = 12) {
  const d = t - start;
  return d < 0 || d > 0.7 ? 0 : amplitude * Math.sin(d * hz * Math.PI * 2) * Math.exp(-d * decay);
}
function seeded(start) {
  let state = start >>> 0;
  return () => { state = (1664525 * state + 1013904223) >>> 0; return state / 4294967296; };
}
const rgba = (r, g, b, a) => "rgba(" + r + "," + g + "," + b + "," + clamp(a) + ")";
const paths = new Map();
function inkPath(d) {
  let p = paths.get(d);
  if (!p) { p = new Path2D(d); if (paths.size < 12000) paths.set(d, p); }
  return p;
}

function brushes(canvas) {
  const g = canvas.getContext("2d");
  g.lineJoin = "round";
  g.lineCap = "round";

  function path(d, fill, edge, weight = 1) {
    const shape = typeof d === "string" ? inkPath(d) : d;
    if (fill) { g.fillStyle = fill; g.fill(shape); }
    if (edge) { g.strokeStyle = edge; g.lineWidth = weight; g.stroke(shape); }
  }
  function stroke(d, color, weight = 1) { path(d, null, color, weight); }
  function line(x0, y0, x1, y1, color, w = 1) {
    g.beginPath(); g.moveTo(x0,y0); g.lineTo(x1,y1);
    g.strokeStyle = color; g.lineWidth = w; g.stroke();
  }
  function poly(points, fill, edge, weight = 1) {
    g.beginPath(); g.moveTo(points[0][0], points[0][1]);
    for (let i=1;i<points.length;i++) g.lineTo(points[i][0], points[i][1]);
    g.closePath();
    if (fill) { g.fillStyle = fill; g.fill(); }
    if (edge) { g.strokeStyle = edge; g.lineWidth = weight; g.stroke(); }
  }
  function rect(x,y,w,h,color) { g.fillStyle = color; g.fillRect(x,y,w,h); }
  function box(x,y,w,h,r,fill,edge,weight=1) {
    if (w<=0 || h<=0) return;
    g.beginPath(); g.roundRect(x,y,w,h,r);
    if (fill) { g.fillStyle=fill; g.fill(); }
    if (edge) { g.strokeStyle=edge; g.lineWidth=weight; g.stroke(); }
  }
  function ell(x,y,rx,ry,fill,edge,weight=1) {
    g.beginPath(); g.ellipse(x,y,rx,ry,0,0,Math.PI*2);
    if (fill) { g.fillStyle=fill; g.fill(); }
    if (edge) { g.strokeStyle=edge; g.lineWidth=weight; g.stroke(); }
  }
  function gradient(x0,y0,x1,y1,stops) {
    const grad = g.createLinearGradient(x0,y0,x1,y1);
    for (const [u,col] of stops) grad.addColorStop(u,col);
    return grad;
  }
  function wash(x,y,rx,ry,colors) {
    g.save(); g.translate(x,y); g.scale(rx,ry);
    const grad = g.createRadialGradient(0,0,0,0,0,1);
    for (const [u,col] of colors) grad.addColorStop(u,col);
    rect(-1,-1,2,2,grad); g.restore();
  }
  function halo(x,y,rx,ry,rgb,power) {
    if (power<=0) return;
    const [red,green,blue] = rgb;
    wash(x,y,rx,ry,[[0,rgba(red,green,blue,power)],[.46,rgba(red,green,blue,power*.53)],[1,rgba(red,green,blue,0)]]);
  }
  function txt(value,x,y,size,color,options={}) {
    const { weight=600, align="left", fixed=false, outline=0 }=options;
    g.font = weight+" "+size+'px '+(fixed?'"Menlo",monospace':'"PingFang SC",sans-serif');
    g.textAlign=align; g.textBaseline="alphabetic"; g.lineJoin="round";
    if (outline) { g.strokeStyle="#091116";g.lineWidth=outline;g.strokeText(value,x,y); }
    g.fillStyle=color;g.fillText(value,x,y);
  }
  function at(x,y,sx,sy,angle,draw) {
    g.save(); g.translate(x,y); if (angle) g.rotate(angle); g.scale(sx,sy); draw(); g.restore();
  }
  function clip(d,draw) { g.save(); g.clip(inkPath(d)); draw(); g.restore(); }
  return { g, path, stroke, line, poly, rect, box, ell, gradient, wash, halo, txt, at, clip };
}

module.exports={clamp,mix,ramp,impulse,seeded,rgba,brushes,createCanvas};
