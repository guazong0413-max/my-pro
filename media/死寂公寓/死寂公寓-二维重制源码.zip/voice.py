"""Generate the cast's original Mandarin lines in the scene's cue order."""

import argparse
import json
import sys
import wave
from pathlib import Path

ROOT = Path(__file__).resolve().parent
LOCAL_PACKAGES = ROOT / 'deps'
if LOCAL_PACKAGES.is_dir():
    sys.path.insert(0, str(LOCAL_PACKAGES))

import mlx.core as mx
import numpy as np
from mlx_audio.tts.utils import load_model


ROLES = {
    'story': ('Uncle_Fu', '口语化的普通话叙述，亲近、沉稳、连贯，约每秒五个汉字，标点停顿很短。'),
    'tense': ('Uncle_Fu', '普通话低声讲述，语气克制，像在说自己目睹的事。字句连读，每秒约五字，停顿很短。'),
    'chen': ('Dylan', '年轻男人刚醒，在黑暗房间里自言自语，普通话。声音小，带一点气息和疑惑，像现实中的小声说话。语速自然，也别拖长。'),
    'phone': ('Serena', '普通话女声在手机里播发应急通知，清晰冷静，平稳地连贯说完，逗号停顿短。'),
}


def voiced_segment(audio, rate):
    padded = np.pad(audio, (0, (-len(audio)) % 240))
    rms = np.sqrt(np.mean(padded.reshape(-1, 240)**2, axis=1))
    threshold = max(0.001, rms.max() * 0.024)
    active = np.flatnonzero(rms > threshold)
    if not len(active):
        raise ValueError('no audible speech')
    return audio[max(0, active[0] * 240 - int(rate * .045)):
                 min(len(audio), (active[-1] + 1) * 240 + int(rate * .095))]


def synthesize(synth, line, index):
    speaker, direction = ROLES[line['role']]
    window = line['until'] - line['at']
    best = None
    for take in range(4):
        mx.random.seed(9841 + index * 211 + take * 53)
        instruction = direction if not take else direction + ' 稍快，停顿很短，句末迅速落下来。'
        pieces = list(synth.generate_custom_voice(
            text=line['text'], speaker=speaker, language='chinese',
            instruct=instruction, temperature=.72, top_p=.90,
            repetition_penalty=1.08, max_tokens=220,
        ))
        rate = pieces[0].sample_rate
        raw = np.concatenate([np.asarray(piece.audio).reshape(-1) for piece in pieces])
        try:
            audio = voiced_segment(raw, rate)
        except ValueError:
            continue
        duration = len(audio) / rate
        if duration < len(line['text']) * .085 or duration > 12.0:
            continue
        # Prefer a complete line that fits the edit without appreciable speed changes.
        cost = max(0., duration - window * 1.06) + max(0., window * .71 - duration) * .45
        if best is None or cost < best[0]:
            best = (cost, audio, rate)
        if duration <= window * 1.11:
            break
    if best is None:
        raise RuntimeError(f'no usable speech on line {index + 1}')
    _, audio, rate = best
    path = ROOT / 'audio' / f'voice-{index + 1:02}.wav'
    with wave.open(str(path), 'wb') as output:
        output.setparams((1, 2, rate, 0, 'NONE', 'not compressed'))
        output.writeframes((audio.clip(-1, 1) * 32767).astype('<i2').tobytes())
    print(f'{path.name} {speaker:8} {len(audio)/rate:.2f}s / {window:.2f}s  {line["text"]}', flush=True)


def main():
    cli = argparse.ArgumentParser(description=__doc__)
    cli.add_argument('--model', type=Path, default=ROOT / 'model')
    cli.add_argument('--only', type=int, nargs='+')
    cli.add_argument('--replace', action='store_true')
    args = cli.parse_args()
    speech = json.loads((ROOT / 'plan.json').read_text(encoding='utf-8'))['speech']
    (ROOT / 'audio').mkdir(exist_ok=True)
    synth = load_model(str(args.model.resolve()))
    print('Loaded Qwen3-TTS CustomVoice', flush=True)
    for index, line in enumerate(speech):
        if args.only and index + 1 not in args.only:
            continue
        if args.replace or not (ROOT / 'audio' / f'voice-{index + 1:02}.wav').exists():
            synthesize(synth, line, index)


if __name__ == '__main__':
    main()
