# 死寂公寓 · 雨夜二维重制

90 秒，1920×1080，30 帧每秒。楼景、室内、手机、人物和警车由 Canvas 路径绘制，配音与现场效果在独立音轨上剪辑。原参考视频的画面和音轨没有进入项目。

## 渲染

安装 Node.js、FFmpeg 和带 NumPy 的 Python。中文排版使用苹方，系统会在缺少苹方时使用默认无衬线字体。

```sh
npm install --no-save --no-package-lock @napi-rs/canvas@1.2.0
node check-motion.cjs
python3 mix.py
node render.cjs
ffmpeg -i picture.mp4 -i sound-mix.wav -map 0:v:0 -map 1:a:0 -c:v copy -c:a aac -b:a 256k -movflags +faststart master.mp4
```

附带已生成的 18 条对白，可直接渲染。需要改台词时，先编辑 `plan.json`，然后在苹果芯片 Mac 的 Python 环境中安装 `mlx-audio`。将模型下载到本项目的 `model/`，运行 `python3 voice.py --replace` 和 `python3 mix.py`。`python3 voice.py --only 4 --replace` 可重做单句。 [Qwen3-TTS](https://github.com/QwenLM/Qwen3-TTS) · [MLX 模型](https://huggingface.co/mlx-community/Qwen3-TTS-12Hz-1.7B-CustomVoice-4bit)

| 文件 | 内容 |
| --- | --- |
| `plan.json` | 剪辑点、配音、震动、脚步、坠落和门锁时间 |
| `rig.cjs` | 共用侧脸、肢体和衣服，脚跟和脚尖支点，后退与站起动作 |
| `sets.cjs` · `street.cjs` · `shots.cjs` | 布景、车身和光线，逐镜头绘制与剪辑 |
| `voice.py` · `mix.py` | 普通话语音、音效分轨混音、对白口型采样 |
| `check-motion.cjs` | 足底落点、关节伸展范围、警车方向检查 |

## 音频来源

- 雨打窗户，alxl。[Rain On Window Loop](https://opengameart.org/content/rain-on-window-loop)
- 手机在木面上振动，metaxis。[Freesound](https://freesound.org/people/metaxis/sounds/708216/)
- 赤脚步声，FOSSarts。[Freesound](https://freesound.org/people/FOSSarts/sounds/740294/)
- 车辆警笛，conleec。[Freesound](https://freesound.org/people/conleec/sounds/159747/)
- 门锁，Areti18。[Freesound](https://freesound.org/people/Areti18/sounds/394943/)
- 衣料摩擦和撞击，Kenney。[RPG Audio](https://kenney.nl/assets/rpg-audio) · [Impact Sounds](https://kenney.nl/assets/impact-sounds)

这些音效素材以 CC0 发布。对白是按本片台词生成的语音。
