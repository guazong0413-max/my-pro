"""Edit the recorded sound effects and Mandarin performances against picture."""

from pathlib import Path
import json
import math
import subprocess
import wave

import numpy as np


ROOT = Path(__file__).resolve().parent
AUDIO = ROOT / 'audio'
PLAN = json.loads((ROOT / 'plan.json').read_text(encoding='utf-8'))
RATE = 48000
FRAME_COUNT = round(PLAN['duration'] * PLAN['fps'])


def read_audio(path, filters='', channels=1, start=None, length=None):
    command = ['ffmpeg', '-nostdin', '-v', 'error']
    if start is not None:
        command += ['-ss', str(start)]
    command += ['-i', str(path)]
    if length is not None:
        command += ['-t', str(length)]
    if filters:
        command += ['-af', filters]
    command += ['-ac', str(channels), '-ar', str(RATE), '-f', 'f32le', 'pipe:1']
    decoded = np.frombuffer(subprocess.check_output(command), dtype='<f4').copy()
    return decoded if channels == 1 else decoded.reshape(-1, channels)


def db_gain(db):
    return 10**(db / 20)


def edge_fade(audio, entrance=.012, exit=.033):
    n = min(len(audio), round(entrance * RATE))
    if n:
        audio[:n] *= np.linspace(0, 1, n, dtype=np.float32)
    n = min(len(audio), round(exit * RATE))
    if n:
        audio[-n:] *= np.linspace(1, 0, n, dtype=np.float32)
    return audio


def at_peak(audio, db):
    peak = np.max(np.abs(audio))
    return audio * (db_gain(db) / max(peak, 1e-5))


def at_rms(audio, db, active=False, peak_db=-6.0):
    basis = audio
    if active:
        width = RATE // 50
        frames = audio[:len(audio) // width * width].reshape(-1, width)
        rms = np.sqrt(np.mean(frames**2, axis=1))
        basis = frames[rms > rms.max() * .16]
    rms = np.sqrt(np.mean(basis**2))
    gain = min(db_gain(db) / max(rms, 1e-5), db_gain(peak_db) / max(np.max(np.abs(audio)), 1e-5))
    return audio * gain


def pan(samples, position):
    theta = (np.asarray(position) + 1) * np.pi / 4
    return np.stack((samples * np.cos(theta), samples * np.sin(theta)), axis=-1)


def place(bus, samples, at, position=0.0):
    start = round(at * RATE)
    if samples.ndim == 1:
        samples = pan(samples, position)
    end = min(len(bus), start + len(samples))
    bus[start:end] += samples[:end-start]


def crossfade_loop(sample, frames):
    distance = round(RATE * .93)
    period = len(sample) - distance
    output = np.zeros((frames + len(sample), sample.shape[1]), dtype=np.float32)
    blend = np.linspace(0, 1, distance, dtype=np.float32)[:, None]
    clip = sample.copy()
    clip[:distance] *= blend
    clip[-distance:] *= 1 - blend
    for start in range(0, frames, period):
        output[start:start+len(clip)] += clip
    return output[:frames]


def put_voice(bus):
    roles = {
        'story': ('highpass=f=74,equalizer=f=210:t=q:w=1.0:g=-1.4', -20.4, .0),
        'tense': ('highpass=f=75,equalizer=f=220:t=q:w=1.0:g=-1.5', -21.1, .0),
        'chen': ('highpass=f=86,equalizer=f=1800:t=q:w=1.0:g=-1.5', -23.9, .07),
        'phone': ('highpass=f=295,lowpass=f=4130,equalizer=f=1350:t=q:w=1.0:g=1.4', -22.7, .08)
    }
    mouth = np.zeros(FRAME_COUNT, dtype=np.float32)
    lengths = []
    for i, cue in enumerate(PLAN['speech'], 1):
        source = AUDIO / f'voice-{i:02}.wav'
        with wave.open(str(source), 'rb') as stream:
            raw_length = stream.getnframes() / stream.getframerate()
        window = cue['until'] - cue['at'] - .07
        speed = max(1., raw_length / window)
        if speed > 1.19:
            raise ValueError(f'{source.name} needs another take at a better pace ({speed:.2f}x)')
        eq, level, position = roles[cue['role']]
        filters = f'atempo={speed:.6f},{eq}'
        voice = read_audio(source, filters)
        voice = at_rms(edge_fade(voice), level, active=True, peak_db=-5.9)
        place(bus, voice, cue['at'], position)
        lengths.append([i, speed, round(len(voice)/RATE, 3)])
        if cue['role'] == 'chen':
            start = math.ceil(cue['at'] * PLAN['fps'])
            end = min(FRAME_COUNT, math.ceil((cue['at']+len(voice)/RATE)*PLAN['fps']))
            for frame in range(start, end):
                a = round((frame / PLAN['fps'] - cue['at']) * RATE)
                b = min(len(voice), a + RATE // PLAN['fps'])
                if b > a:
                    mouth[frame] = np.clip((np.sqrt(np.mean(voice[a:b]**2)) - .012) / .11, 0., 1.)
    (ROOT / 'performance.json').write_text(
        json.dumps({'mouth': {str(i): round(float(g), 3) for i, g in enumerate(mouth) if g > .01}},
                   separators=(',', ':')), encoding='utf-8')
    print('Voice edit (cue, speed, final seconds):', lengths, flush=True)


def put_rain(bus, voice):
    path = AUDIO / 'window.wav'
    interior = read_audio(path, 'highpass=f=94,lowpass=f=1580', channels=2)
    exposed = read_audio(path, 'highpass=f=132,lowpass=f=7000', channels=2)
    interior = crossfade_loop(at_rms(interior, -32.5), len(bus))
    exposed = crossfade_loop(at_rms(exposed, -29.8), len(bus))
    key = np.array([0, 3.4, 4, 13.6, 16, 20, 23.93, 29.0, 34.85, 36.9, 56.15,
                    56.5, 57.3, 61.68, 64.1, 74, 81.9, 83.0, 85.05, 87.75, 90])
    opening = np.array([.29, .29, .0, .0, .09, .19, .35, .72, .88, 1, 1,
                        .44, .07, .09, .38, .34, .02, .0, .0, .0, .0])
    levels = np.array([-6, -1, -3, -3, -3, -2, -.5, 0, -1, 1, 0,
                       -.5, -2, -1, 1.1, .6, -5.2, -8, -10.8, -16, -90])
    t = np.arange(len(bus), dtype=np.float32) / RATE
    blend = np.interp(t, key, opening)[:, None]
    gain = np.power(10., np.interp(t, key, levels)[:, None]/20.)
    frames = RATE//40
    dry = voice[:len(voice)//frames*frames].reshape(-1, frames, 2)
    rms = np.sqrt(np.mean(dry**2, axis=(1, 2)))
    occupancy = np.clip((rms - .014)/.08, 0, 1)
    smoothed = np.convolve(occupancy, np.full(13, 1/13), mode='same')
    duck = np.interp(t, np.arange(len(rms), dtype=np.float32)/40, 1-.30*smoothed)[:, None]
    bus[:] += ((1-blend) * interior + blend * exposed) * gain * duck


def put_effects(bus):
    events = PLAN['events']
    for time, start, level in zip(events['buzz'], [.078, 1.274, 2.521], [-15, -16.5, -15.9]):
        sample = read_audio(AUDIO/'buzz.mp3', 'highpass=f=55,lowpass=f=1530',
                            start=start, length=.46)
        place(bus, at_peak(edge_fade(sample, .012, .069), level), time, .40)

    footstep_sources = [.588, 1.086, 1.532, 2.585, 3.137, 2.028, 3.637, 1.728]
    soft = 'highpass=f=65,lowpass=f=2390'
    steps = [(events['bare'], 0, .29, -.38, -15.3),
             (events['back'], 3, -.15, .18, -18.1),
             (events['hide'], 4, -.11, .27, -20.7)]
    for times, index, begin, end, level in steps:
        for i, time in enumerate(times):
            source = footstep_sources[(i+index) % len(footstep_sources)]
            step = read_audio(AUDIO/'bare.mp3', soft, start=source, length=.26)
            style = level - 1.45*(i%2)
            position = np.linspace(begin, end, len(times))[i]
            place(bus, at_peak(edge_fade(step,.004,.054),style), time-.014, position)

    siren = read_audio(AUDIO/'siren.mp3', 'highpass=f=240,lowpass=f=2350',
                       start=27.90, length=5.40)
    siren = edge_fade(at_peak(siren, -17.6), 1.03, 1.38)
    field = np.linspace(-.86, .88, len(siren), dtype=np.float32)
    place(bus, siren, 23.73, field)

    rustle = 'highpass=f=130,lowpass=f=4200'
    for time, name, level, position in [
        (events['fall']-.06,'cloth2.ogg',-22,.27),
        (events['impact']+.036,'cloth4.ogg',-15.8,.16),
        (events['twitch'],'cloth1.ogg',-27,.09),
        (events['rise'][0],'cloth2.ogg',-24,.08),
        (events['rise'][1],'cloth4.ogg',-23,.12),
        (events['rise'][2],'cloth1.ogg',-21.5,.15),
        (events['rise'][3],'cloth3.ogg',-22,.20),
        (events['curtain'],'cloth3.ogg',-16.2,-.38),
    ]:
        sample = read_audio(AUDIO/name, rustle)
        place(bus, at_peak(edge_fade(sample,.009,.051),level), time, position)

    impact = read_audio(AUDIO/'impactSoft_heavy_003.ogg', 'highpass=f=43,lowpass=f=1820')
    place(bus, at_peak(edge_fade(impact,.003,.055),-9.3), events['impact'], .12)
    block = read_audio(AUDIO/'impactSoft_medium_004.ogg', 'highpass=f=89,lowpass=f=1200')
    place(bus, at_peak(edge_fade(block,.004,.055),-19.7), events['wall'], .18)

    latch = read_audio(AUDIO/'latch.mp3', 'highpass=f=155,lowpass=f=5250', start=.302, length=.77)
    place(bus, at_peak(edge_fade(latch,.007,.081),-13.9), events['latch']-.032, .10)
    handle = read_audio(AUDIO/'latch.mp3', 'highpass=f=205,lowpass=f=4100', start=1.16, length=.32)
    place(bus, at_peak(edge_fade(handle,.004,.073),-21), events['latch']+.49, .10)


def main():
    frames = round(PLAN['duration'] * RATE)
    speech = np.zeros((frames, 2), dtype=np.float32)
    scene = np.zeros_like(speech)
    put_voice(speech)
    put_rain(scene, speech)
    put_effects(scene)
    mixed = speech + scene
    path = ROOT / 'sound-mix.wav'
    filters = 'loudnorm=I=-16.5:LRA=8:TP=-1.25:linear=true'
    command = ['ffmpeg', '-nostdin', '-v', 'error', '-y', '-f', 'f32le', '-ar', str(RATE), '-ac', '2',
               '-i', 'pipe:0', '-af', filters, '-ar', str(RATE), '-c:a', 'pcm_s24le', str(path)]
    subprocess.run(command, input=mixed.tobytes(), check=True)
    print(f'Linked {len(PLAN["speech"])} performances to audio and picture. Stereo master: {path}')


if __name__ == '__main__':
    main()
