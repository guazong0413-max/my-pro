"use strict";

const {brushes,clamp,mix,ramp,impulse,seeded,rgba,createCanvas}=require("./ink.cjs");
const {W,H,createSets}=require("./sets.cjs");
const {createCast,walkState}=require("./rig.cjs");
const {createStreet,carState}=require("./street.cjs");
const PLAN=require("./plan.json");
const {mouth}=require("./performance.json");

const blue=[157,202,229], red=[195,59,47];
const full="M0 0 H960 V540 H0Z";
const glass="M143 61 H817 V515 H143Z";

function createFilm(canvas) {
  const scale=canvas.width/W, b=brushes(canvas);
  const {g,path,stroke,line,poly,rect,box,ell,gradient,halo,txt,at,clip}=b;
  const sets=createSets(b), cast=createCast(b), street=createStreet(b);
  const cuts=PLAN.cuts, events=PLAN.events;
  const weather=seeded(1481);
  const falling=Array.from({length:270},(_,i)=>({
    x:weather()*1024, y:weather()*628, speed:mix(280,715,weather()),
    length:mix(6,42,weather()), depth:i%3
  }));
  const rainTone=["#7196a5","#7fa4b3","#8ba9b8"];
  const grain=createCanvas(256,256), grainCtx=grain.getContext("2d");
  const grainPixels=grainCtx.createImageData(256,256);
  const random=seeded(91171);
  for(let i=0;i<grainPixels.data.length;i+=4){
    const v=random()<.52?0:170;
    grainPixels.data[i]=v; grainPixels.data[i+1]=v;
    grainPixels.data[i+2]=v?177:10; grainPixels.data[i+3]=Math.floor(random()*16);
  }
  grainCtx.putImageData(grainPixels,0,0);
  const texture=g.createPattern(grain,"repeat");

  function plate(build) {
    const margin=64;
    const raster=createCanvas((W+2*margin)*scale,(H+2*margin)*scale);
    const painter=brushes(raster);
    painter.g.setTransform(scale,0,0,scale,margin*scale,margin*scale);
    build(createSets(painter));
    return ()=>g.drawImage(raster,-margin,-margin,W+2*margin,H+2*margin);
  }

  const city=plate(p=>p.city()), bedroom=plate(p=>p.bedroom());
  const road=plate(p=>p.streetPlate());
  const building=plate(p=>p.balcony()), garden=plate(p=>p.planter());
  const lounge=plate(p=>p.living()), door=plate(p=>p.closeDoor());

  function rain(t,alpha,fallSpeed=1,intensity=1) {
    g.save();
    for(let layer=0;layer<3;layer++) {
      g.beginPath();
      for(let i=layer;i<falling.length*intensity;i+=3) {
        const p=falling[i], n=(p.y+t*p.speed*fallSpeed)%628;
        const x=(p.x+1024-(t*p.speed*.135)%1024)%1024-32;
        const y=n-43, span=p.length*(.64+.18*layer);
        g.moveTo(x,y);g.lineTo(x-span*.143,y+span);
      }
      g.strokeStyle=rainTone[layer];
      g.globalAlpha=alpha*(.41+.13*layer);
      g.lineWidth=.44+.33*layer;g.stroke();
    }
    g.restore();
  }

  function drops(t,x,y,w,h,alpha) {
    g.save();
    g.beginPath();g.rect(x,y,w,h);g.clip();
    const r=seeded(194);
    for(let i=0;i<38;i++){
      const xx=x+r()*w, p=r(), speed=mix(13,65,r());
      const yy=y+(p*h+speed*t)%h, size=mix(1.1,4.5,r());
      line(xx+.21*size,yy-1.9*size,xx,yy+size,rgba(...blue,alpha*.30),.54+size*.17);
      ell(xx,yy,.35+size*.15,.53+size*.25,rgba(...blue,alpha*.54));
    }
    g.restore();
  }

  function lens(cx,cy,zoom,dx,dy,draw) {
    at(cx+dx,cy+dy,zoom,zoom,0,()=>at(-cx,-cy,1,1,0,draw));
  }

  function vibrate(t) {
    let motion=0, light=0;
    for(const cue of events.buzz) {
      const p=t-cue;
      if(p>=0&&p<.52) {
        const gate=ramp(p,0,.045)*(1-ramp(p,.32,.52));
        motion+=Math.sin(p*Math.PI*31)*gate;
        light=Math.max(light,ramp(p,0,.08));
      }
      if(p>=.52&&p<1.43)light=Math.max(light,1-.55*ramp(p,.52,1.43));
    }
    return {motion,light};
  }

  function opening(t) {
    lens(540,280,1.05+.037*ramp(t,0,cuts[1]),0,0,()=>{
      city();
      rain(t,.24);
    });
    rect(0,0,W,H,gradient(72,96,378,348,[[0,"rgba(2,8,14,.49)"],[1,"rgba(2,8,14,0)"]]));
    const a=ramp(t,.55,1.30)*(1-ramp(t,3.20,3.60));
    txt(PLAN.title,97,137,29,rgba(233,239,231,a*.92),{weight:580});
    line(98,149,171,149,rgba(...blue,a*.35),.9);
    txt("凌晨 02:17",853,130,15,rgba(204,218,218,a*.76),{weight:500,align:"right"});
    rect(0,0,W,H,rgba(3,8,13,1-ramp(t,0,1.03)));
  }

  function sleeping(t) {
    const awake=ramp(t,6.97,7.96),buzz=vibrate(t);
    lens(596,344,1.018+.070*ramp(t,3.65,8.48),0,0,()=>{
      bedroom();
      drops(t,126,104,220,264,.30);
      path("M621 397 Q632 369 666 372 Q704 371 728 392 L728 405 H621Z","#425462","#5f7076",.93);
      line(673,395,716,396,"rgba(140,167,173,.31)",1);
      at(686+8*awake,372-13*awake,-1,1,0,()=>{
        cast.head(0,0,.86,-1.55+.46*awake,0,0,.26+buzz.light*.27);
      });
      const y=347+Math.sin(t*2.4)*1.4;
      path("M342 395 C363 373 399 371 434 363 C494 "+(y-7)+" 566 "+y+" 604 367 Q635 370 665 387 L673 409 L350 416 Q343 412 342 395Z",
        gradient(452,360,492,416,[[0,"#425769"],[.42,"#334957"],[1,"#243764"]]),"#4d6470",.7);
      path("M345 399 C395 387 436 379 464 386 C516 393 596 377 653 392 L673 410 L352 416Z","rgba(13,29,43,.24)");
      stroke("M365 399 Q420 383 479 388 Q523 389 550 381","rgba(126,151,163,.31)",.98);
      at(794+buzz.motion*1.6,356+buzz.motion*.32,1,1,0,()=>{
        poly([[-20,4],[-10,-5],[25,-4],[26,3]],"#101b24","#526770",.75);
        poly([[-17,2],[-9,-4],[22,-3],[24,1]],rgba(116,184,221,.20+.71*buzz.light));
        halo(2,-1,74,24,blue,.10+.35*buzz.light);
        halo(2,-2,25,8,[198,229,251],.28*buzz.light);
        line(-8,0,17,0,rgba(188,226,243,.83*buzz.light),1.2);
      });
      rect(0,0,W,H,"rgba(3,9,15,.34)");
    });
  }

  const notices=[
    ["紧急通知","请关好门窗，切勿外出。"],
    ["社区警示","请留在室内，保持安静。"],
    ["应急提醒","暂勿前往楼道或公共区域。"]
  ];
  function phone(t) {
    rect(0,0,W,H,gradient(712,87,247,449,[[0,"#232323"],[.67,"#151b20"],[1,"#0a131b"]]));
    for(let i=0;i<6;i++)line(-31,82+i*91,1011,3+i*91,"rgba(117,103,82,.12)",1.13);
    halo(512,286,372,286,[141,84,68],.215);
    const buzz=vibrate(t),zoom=1+.055*ramp(t,8.48,13.63);
    at(498+buzz.motion*.95,264+buzz.motion*.38,zoom,zoom,-.102-.017*ramp(t,8.48,13.63),()=>{
      halo(12,35,160,264,[2,8,12],.72);
      box(-108,-218,216,440,23,"#0c1018","#62646b",1.1);
      box(-101,-211,202,426,19,gradient(-93,-192,94,203,[[0,"#433747"],[.43,"#352e3b"],[1,"#45282c"]]));
      path("M-99 -48 C-30 -92 32 -33 99 -85 V194 Q98 218 75 214 H-77 Q-99 210 -100 191Z","rgba(134,53,46,.095)");
      box(-28,-202,56,8,4,"#161925");
      txt("02:17",0,-101,45,"#eef0e4",{align:"center",fixed:true,weight:420});
      txt("紧急预警",0,-141,11,"#c3bdc8",{align:"center",weight:500});
      stroke("M69 -185 H82 V-178 H69Z M83 -183 H85 V-180 H83Z","#c3bdc8",.69);
      rect(71,-183,8,3.4,"#c3bdc8");
      events.phone.forEach((cue,i)=>{
        const a=ramp(t,cue,cue+.26);
        if(a<=0)return;
        g.save();g.globalAlpha*=a;
        const y=-71+i*65-9*(1-a);
        box(-88,y,176,57,7,i===1?"#343a48":"#4c3c46");
        box(-79,y+11,13,13,3,i===1?"#63869c":"#c75043");
        txt("!",-72.5,y+22,9,"#fff0e2",{align:"center",weight:690});
        txt(notices[i][0],-60,y+22,11,"#ece2df",{weight:740});
        txt(notices[i][1],-78,y+43,10,"#d6cacf",{weight:520});
        g.restore();
      });
      box(-27,199,54,2.8,1.3,"#9a7c86");
    });
  }

  function sideLight(t) {
    rect(0,0,W,H,gradient(319,410,827,85,[[0,"#080f15"],[.67,"#101e28"],[1,"#13212b"]]));
    poly([[49,-28],[124,-24],[445,506],[366,540]],gradient(60,3,410,509,
      [[0,"rgba(104,151,175,.21)"],[1,"rgba(96,145,167,0)"]]));
    halo(753,489,305,149,blue,.113);
    const x=463+4*ramp(t,13.63,15.82),y=270-3*ramp(t,13.63,15.82);
    const talk=mouth[Math.round(t*PLAN.fps)]||0;
    cast.portrait(x,y,4.87,1,{tilt:-.025,bright:.28,look:.1,
      mouth:talk,breathe:Math.sin((t-13.63)*2.8)*.26});
    rect(0,0,W,H,gradient(308,265,571,392,[[0,"rgba(0,6,10,.71)"],[.78,"rgba(2,8,15,.38)"],[1,"rgba(4,11,18,.14)"]]));
    halo(746,509,197,100,[91,154,212],.13);
  }

  function footsteps(t) {
    const bodyScale=4.22;
    const progress=walkState(t).hip[0];
    const track=(progress+23)*bodyScale*.58;
    sets.oakDetail(track);
    cast.walker(678+track,420,bodyScale,-1,t,"wake");
    rect(0,0,W,H,gradient(0,260,0,493,[[0,"rgba(5,11,16,.51)"],[1,"rgba(5,11,16,.37)"]]));
  }

  function rule(kind,x,y,alpha) {
    const lines=kind===1?["夜间遇险，先别开灯","光会暴露你所在的房间。"]:["未知危险面前，先藏好自己","关紧门窗，保持安静。"];
    rect(x,y,2,89,rgba(202,86,65,alpha*.89));
    txt(kind===1?"生存法则  01":"生存法则  02",x+14,y+14,11,rgba(225,108,86,alpha*.98),{weight:650});
    txt(lines[0],x+14,y+49,28,rgba(226,237,228,alpha),{weight:700});
    txt(lines[1],x+15,y+74,12,rgba(170,188,190,alpha*.90),{weight:500});
  }

  function warning(t) {
    const pulse=ramp(t,19.63,20.24);
    city();rain(t,.19);
    rect(0,0,W,H,gradient(118,220,745,254,[[0,"rgba(2,9,14,.79)"],[1,"rgba(2,9,14,.09)"]]));
    const [x,y]=sets.signal(pulse);
    const ring=ramp(t,20.01,21.12),focus=42+19*ring;
    ell(x,y,focus,focus,undefined,rgba(...blue,.40*ring),1);
    ell(x,y,focus+16,focus+16,undefined,rgba(...blue,.13*ring),.75);
    line(x+focus*.72,y-focus*.72,x+focus+22,y-focus-10,rgba(...blue,.44*ring),.86);
    txt("隔街可见",x+focus+27,y-focus-8,12,rgba(191,216,217,.85*ring),{weight:500});
    rule(1,74,181,ramp(t,19.12,19.66));
  }

  function throughWindow(t) {
    rect(0,0,W,H,"#0b1520");
    clip(glass,()=>{
      road();street.patrol(t);
      if(t>27.78)cast.cloaked(628.56,207.76,.275,.033);
      rain(t,.34);drops(t,143,61,674,446,.32);
      const d=carState(t);
      halo(480,465,510,66,[105,144,170],.09);
      halo(d.x-8,421,115,116,[114,168,222],.075);
      rect(142,63,676,452,"rgba(3,10,16,.16)");
    });
    rect(0,57,143,466,"#111d29");
    rect(816,54,144,473,"#101d27");
    rect(146,51,669,12,"#111d29");
    const breath=Math.sin(t*1.8)*.025;
    sets.curtain(-31,-28,216,583,.66+breath,1,"#0a1824");
    sets.curtain(990,-24,218,584,.63-breath,-1,"#0a1824");
    line(169,524,790,524,"#384c58",1.6);
    rect(0,527,W,15,"#0d1b25");
  }

  function balcony(t,fallingShot=false) {
    const slack=ramp(t,events.fall-.25,events.fall+.17);
    const dropTime=clamp((t-events.fall)/(events.impact-events.fall));
    const distance=602*dropTime**2;
    const roll=.033+.94*dropTime**1.7;
    const offset=fallingShot?Math.max(0,distance-38)*.85/136:0;
    const baseZoom=1.025+.035*ramp(t,28.49,34.28);
    lens(640,316,baseZoom,0,0,()=>{
      if(fallingShot)sets.balcony(offset);
      else building();
      halo(645,308,95,133,[8,16,24],.28);
      const y=332+distance-offset*136;
      cast.cloaked(646+32*dropTime,y,.70,roll,slack);
      rain(t,.30,.98);
      rect(-20,-20,1000,580,"rgba(3,10,17,.38)");
    });
  }

  function splashes(t) {
    const d=t-events.impact;
    if(d<0||d>.62)return;
    const r=seeded(4521);
    for(let i=0;i<17;i++){
      const v=mix(-191,160,r()),vy=mix(48,128,r());
      const x=522+v*d,y=419-vy*d+192*d*d;
      if(y<419)line(x,y,x+v*.026,y+2.4,rgba(144,171,170,.45*(1-d/.62)),.7);
    }
    ell(526,417,20+57*d,2.3+8*d,undefined,rgba(144,171,170,.64*(1-d/.62)),.78);
  }

  function planter(t) {
    const n=t-events.impact,bump=impulse(t,events.impact,6.3,9.4,10);
    const zoom=1.015+.105*ramp(t,44.53,56.41);
    lens(514,385,zoom,0,bump,()=>{
      garden();
      // The near rim hides the part of the figure that enters the planter.
      clip("M-150 -100 H1110 V421 H-150Z",()=>{
        if(n<0) {
          const u=clamp((t-events.impact+.39)/.39);
          // Align the hip here with the first grounded pose at contact.
          cast.cloaked(mix(438,431.4,u),mix(274,409.4,u),1,1.16+.34*u,1);
        }else{
          const twitch=ramp(t,events.twitch,events.twitch+.13)*(1-ramp(t,events.twitch+.21,events.twitch+.48));
          cast.strangerRise(Math.max(0,t-44.53),424,twitch);
        }
      });
      sets.lip();
      splashes(t);
      const oldLights=1-ramp(t,37.05,43.6);
      halo(29,452,398,104,red,.112*oldLights);
      rain(t,.31);
      rect(-25,-18,1005,580,"rgba(4,12,17,.40)");
    });
  }

  function retreat(t) {
    const open=1-ramp(t,events.curtain,events.curtain+.58);
    const shake=impulse(t,events.wall,2.7,8,11);
    const reverseWalk=clamp(58.19-t,.0,1.45);
    lens(462,417,1.24,shake,0,()=>{
      lounge();
      sets.curtain(397,81,118,336,.18+open*.73,-1,"#132433");
      drops(t,202,109,139,284,.36);
      cast.walker(606,475,.95,-1,reverseWalk,"back",{reach:open*.93});
      rect(-25,-25,1010,590,"rgba(4,9,15,.31)");
    });
  }

  function sitting(t) {
    const u=ramp(t,61.68,63.30);
    lens(453,366,1.024+.013*u,0,0,()=>{
      lounge();
      drops(t,198,109,144,282,.60);
      cast.walker(475,475,.91,1,69.83,"hide",{sit:.93,look:Math.sin(t*2.1)*.28,light:.42,mouth:mouth[Math.round(t*PLAN.fps)]||0});
      rect(0,0,W,H,"rgba(2,8,14,.45)");
    });
  }

  function hidden(t) {
    const stand=ramp(t,69.26,69.95),crouch=ramp(t,73.45,74.37);
    lens(603,379,1.035+.018*ramp(t,68.48,80.0),0,0,()=>{
      lounge();drops(t,194,109,148,285,.42);
      cast.walker(475,475,.91,1,clamp(t,69.83,73.42),"hide",
        {sit:.93*(1-stand)+crouch*.95,look:.13+crouch*.14,light:.39});
      rect(0,0,W,H,gradient(71,186,898,369,[[0,"rgba(3,10,17,.55)"],[.64,"rgba(3,10,17,.37)"],[1,"rgba(3,10,17,.50)"]]));
      rect(0,0,W,H,rgba(0,5,10,.58*ramp(t,78.8,81.9)));
    });
    rule(2,70,160,ramp(t,68.60,69.22)*(1-ramp(t,78.0,80.0)));
  }

  function doorstep(t) {
    const turn=ramp(t,events.latch,events.latch+.25)-.79*ramp(t,events.latch+.47,events.latch+.68);
    const shade=ramp(t,events.shade,events.shade+.40);
    const left=323,right=647;
    lens(463,378,1.032+.091*ramp(t,81.90,87.73),0,0,()=>{
      door();
      halo(482,451,243,17,[228,206,158],.11*(1-.55*shade));
      rect(left,445,right-left,1.7,"#a9a48a");
      rect(mix(649,476,shade),444,124*shade,4,"#121a1b");
      poly([[476,446],[600,446],[639,475],[443,471]],rgba(8,13,15,shade*.58));
      box(339,229,13,49,2.5,"#888c7c","#555b55",.81);
      at(346,246,1,1,.36*turn,()=>{
        box(-1,-3.2,46,6.9,2.8,"#b4b2a0");
        line(2,-2,41,-2,"#cbc7b0",.82);
      });
      rect(-28,-23,1019,587,"rgba(2,8,12,.43)");
    });
    rect(0,0,W,H,rgba(0,0,0,ramp(t,87.53,87.73)));
  }

  const shots=[
    opening,sleeping,phone,sideLight,footsteps,warning,throughWindow,
    balcony,t=>t<events.impact-.39?balcony(t,true):planter(t),
    planter,planter,retreat,sitting,hidden,doorstep,()=>{}
  ];

  function finish(t) {
    const screen=g.createRadialGradient(469,266,110,472,266,585);
    screen.addColorStop(0,"rgba(0,6,11,0)");
    screen.addColorStop(.72,"rgba(0,6,11,.16)");
    screen.addColorStop(1,"rgba(0,5,10,.63)");
    rect(0,0,W,H,screen);
    g.save();g.globalAlpha=.26;
    const seed=Math.floor(t*10);
    at(-(seed%4)*19,-(seed%7)*13,1,1,0,()=>rect(0,0,W+80,H+100,texture));
    g.restore();
    const lineForFrame=PLAN.speech.find(cue=>t>=cue.at&&t<cue.until);
    if(!lineForFrame)return;
    const {at:begin,until,role,text}=lineForFrame;
    const opacity=ramp(t,begin,begin+.08)*(1-ramp(t,until-.07,until));
    const shadow=gradient(0,460,0,540,[[0,"rgba(1,4,8,0)"],[.61,"rgba(1,4,8,.53)"],[1,"rgba(1,4,8,.57)"]]);
    rect(0,460,W,80,shadow);
    if(role==="chen")txt("陈默",480,470,11,rgba(175,189,193,opacity*.96),{align:"center",weight:520});
    txt(text,480,499,19,rgba(234,238,232,opacity*.99),{align:"center",weight:480,outline:2.2});
  }

  return function renderFrame(index) {
    const t=index/PLAN.fps;
    g.setTransform(scale,0,0,scale,0,0);
    rect(0,0,W,H,"#000");
    let shot=cuts.length-1;
    while(t<cuts[shot])shot--;
    if(shot===cuts.length-1)return;
    clip(full,()=>shots[shot](t));
    finish(t);
  };
}

module.exports={createFilm};
