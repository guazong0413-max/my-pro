"use strict";

const assert=require("node:assert/strict");
const {walkState,UPPER,LOWER}=require("./rig.cjs");
const {carState}=require("./street.cjs");
const plan=require("./plan.json");

const precision=1e-6, rate=120;
for(const [style,start,end] of [
  ["wake",plan.cuts[4],plan.cuts[5]],
  ["hide",69.83,73.42],
  ["back",0,1.45]
]){
  const previous=[null,null];
  for(let i=Math.ceil(start*rate);i<=Math.floor(end*rate);i++){
    const {hip,near,far}=walkState(i/rate,style);
    const contacts=[near,far].map((foot,index)=>{
      const ground=index===0?0:-7;
      const lowest=Math.max(foot.heel[1],foot.toe[1]);
      assert.ok(lowest<=ground+precision,style+" penetrates floor");
      assert.ok(Math.hypot(hip[0]-3*index-foot.ankle[0],hip[1]-3*index-foot.ankle[1])<UPPER+LOWER,
        style+" exceeds the reach of the leg");
      if(foot.mode==="swing"){
        previous[index]=null;
        return false;
      }
      assert.ok(Math.abs(ground-lowest)<precision,style+" foot loses contact");
      const pivot=foot.mode==="toe"?foot.toe[0]:foot.heel[0], prior=previous[index];
      if(prior&&prior[0]===foot.mode)
        assert.ok(Math.abs(pivot-prior[1])<precision,style+" supporting foot slides");
      previous[index]=[foot.mode,pivot];
      return true;
    });
    assert.ok(contacts.some(Boolean),style+" loses both supports");
  }
}

const carEnter=Math.ceil(plan.cuts[6]*rate);
const carExit=Math.floor(plan.cuts[7]*rate);
for(let i=carEnter+1;i<=carExit;i++){
  const car=carState(i/rate),previous=carState((i-1)/rate);
  assert.ok(car.front>car.x&&car.x>car.tail&&car.heading===1);
  assert.ok(car.x>previous.x&&car.spin>previous.spin);
}

console.log("Ground contact, joint reach and car heading verified at 120 samples per second.");
