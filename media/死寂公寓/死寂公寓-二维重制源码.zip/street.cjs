"use strict";

const {clamp,rgba,mix,ramp}=require("./ink.cjs");
const ENTER=23.93, EXIT=28.49;
const PAINT="#526778", LIGHT=[229,235,212],RED=[248,88,82],BLUE=[87,166,232];

function carState(t) {
  const u=clamp((t-ENTER)/(EXIT-ENTER));
  const x=mix(-120,1090,u);
  return {x,y:431+17*u,scale:mix(.91,1.09,u),heading:1,spin:(x+120)/8.25,
    front:x+62*mix(.91,1.09,u),tail:x-61*mix(.91,1.09,u)};
}

function createStreet(b) {
  const {at,box,ell,gradient,halo,line,path,poly,rect,stroke,txt}=b;

  function wheel(x,a) {
    ell(x,-6.9,10.6,9.5,"#111c26","#2b3b44",1.1);
    ell(x,-6.9,6.55,6.55,"#3b4d58","#79898b",.8);
    at(x,-6.9,1,1,a,()=>{
      for(let j=0;j<5;j++){
        const q=j*Math.PI*2/5;
        line(Math.cos(q)*1.6,Math.sin(q)*1.6,Math.cos(q)*4.9,Math.sin(q)*4.9,"#84908d",.78);
      }
    });
    ell(x,-6.9,1.4,1.4,"#a4a99d");
  }

  function roadSplash(x,y,s,t,alpha) {
    const p=clamp((Math.sin(t*8.2)+.62)*.42);
    halo(x-11,y+15,106*s,10,[125,154,159],.11*alpha);
    for(let i=0;i<7;i++)
      line(x-81*s-i*5.1,y+3+i*.64,x-72*s-i*3.4,y+4+i*.70,
        rgba(123,159,171,(.050+.056*p)*(1-i*.10)*alpha),.63);
  }

  function patrol(t) {
    const {x,y,scale,heading,spin}=carState(t);
    const alpha=ramp(t,ENTER,ENTER+.25);
    const red=.18+.82*Math.pow(Math.max(0,Math.sin((t-ENTER)*10.7)),5);
    const blue=.20+.80*Math.pow(Math.max(0,Math.sin((t-ENTER)*10.7+Math.PI)),5);
    at(x,y,scale*heading,scale,0,()=>{
      // Forward is local +X. Headlamps and bumper move as part of the same transform.
      const head=gradient(62,-11,192,3,[[0,rgba(...LIGHT,.145*alpha)],[.37,rgba(...LIGHT,.077*alpha)],[1,rgba(...LIGHT,0)]]);
      poly([[62,-16],[68,-13],[204,2],[189,13],[65,-6]],head);
      halo(151,8,105,12,LIGHT,.19*alpha);
      halo(-97,12,88,10,RED,.13*alpha);
      halo(-8,5,133,12,RED,.205*red);
      halo(21,11,143,13,BLUE,.179*blue);
      roadSplash(0,0,1,t,alpha);
      for(const [back,front,width] of [[-83,-48,2.1],[-119,-48,1.1],[-140,-70,.62]])
        line(back,9.5+width*1.7,front,8.3+width*1.7,rgba(...RED,.12*alpha),width);

      path("M-64 -7 L-62 -20 Q-61 -23 -56 -24 L-40 -26 L-30 -39 Q-27 -43 -20 -43 H12 Q19 -43 26 -37 L37 -26 L57 -23 Q63 -22 66 -15 L67 -8 L64 -5 H-64Z",
        gradient(-51,-38,63,-5,[[0,"#677883"],[.48,"#98a5a4"],[1,"#657980"]]),"#2b4352",1.1);
      path("M-55 -22 L54 -21 L60 -15 L58 -11 H-61 L-60 -17Z",PAINT);
      path("M-42 -27 L-31 -39 Q-29 -41 -21 -41 H-14 L-15 -27Z","#304c5c");
      path("M-11 -41 H10 Q17 -41 21 -36 L29 -28 L-10 -28Z","#253e4e");
      path("M13 -40 Q20 -39 24 -34 L35 -27 H29 L19 -36Z","#819ba3");
      stroke("M-59 -24 L-38 -26 M-35 -24 L31 -24 L54 -21","rgba(226,232,213,.49)",.92);
      line(12,-26,14,-10,"#425960",.81);
      line(-26,-26,-26,-10,"#405661",.78);
      line(17,-24,23,-24,"#475e69",1.24);
      line(56,-14,65,-14,"#2e434c",.8);
      // A short trunk on the left, lengthened bonnet on the right and distinct lamp colours.
      box(-63,-20,8.2,5.15,1.45,"#d86d63");
      box(56,-20,9.4,5.45,1.45,"#e6e8cd");
      rect(-65,-8,130,3.3,"#485b61");
      txt("警察",-4,-15.65,6.7,"#d8e0d6",{align:"center",weight:760});
      wheel(-43,spin);wheel(42,spin);
      box(-16,-48,33,5.6,1.2,"#304b58");
      box(-15,-47,13.8,3.1,1,rgba(...RED,.42+.58*red));
      box(2,-47,13.7,3.1,1,rgba(...BLUE,.45+.55*blue));
      halo(-8,-46,34,18,RED,.54*red);
      halo(10,-46,34,18,BLUE,.53*blue);
      halo(64,-16,28,12,LIGHT,.225*alpha);
      halo(-61,-17,27,10,RED,.257*alpha);
    });
  }

  return {patrol};
}

module.exports={carState,createStreet};
