"use strict";

const {clamp,mix,ramp,rgba}=require("./ink.cjs");
const pi=Math.PI;
const PLAN=require("./plan.json");
const TOE=25, UPPER=49, LOWER=49;
const WAKE=[{t:15.08,x:-66},{t:15.53,x:-26},...PLAN.events.bare.map((t,i)=>({t,x:13+39*i})),{t:19.41,x:206}];
const HIDE=[{t:69.27,x:-34},{t:69.75,x:-8},...PLAN.events.hide.map((t,i)=>({t,x:28+37*i})),{t:73.42,x:157}];
const BACK=[[-.82,-25],[-.39,8],[.05,52],[.49,96],[.93,140],[1.37,184],[1.80,220]]
  .map(([t,x])=>({t,x}));
const modes={wake:WAKE,hide:HIDE,back:BACK};

function rotated(x,y,angle) {
  const c=Math.cos(angle),s=Math.sin(angle);
  return [x*c-y*s,x*s+y*c];
}

function points(contactX,y,angle,mode) {
  const [tx,ty]=rotated(TOE,0,angle);
  const [ax,ay]=rotated(7,-12,angle);
  return {x:contactX,y,angle,heel:[contactX,y],toe:[contactX+tx,y+ty],ankle:[contactX+ax,y+ay],mode};
}

// Heel, sole and toe each keep one world-space contact while the shoe rolls.
function foot(t,contacts,floor) {
  let i=0;
  while(i+1<contacts.length&&t>=contacts[i+1].t)i++;
  const a=contacts[i],b=contacts[i+1];
  if(!b)return points(a.x,floor,0,"flat");
  const u=clamp((t-a.t)/(b.t-a.t));
  if(u<.12)return points(a.x,floor,-.23*(1-ramp(u,0,.12)),"heel");
  if(u<.46)return points(a.x,floor,0,"flat");
  if(u<.65) {
    const theta=.40*ramp(u,.46,.65);
    return points(a.x+TOE*(1-Math.cos(theta)),floor-TOE*Math.sin(theta),theta,"toe");
  }
  const q=clamp((u-.65)/.35),e=ramp(q,0,1);
  const theta=mix(.40,-.23,e),start=a.x+TOE*(1-Math.cos(.40));
  const x=mix(start,b.x,e);
  const lift=TOE*Math.sin(.40)*(1-q)+16.5*Math.sin(pi*q)**1.1;
  const y=Math.min(floor-lift,floor-Math.max(0,TOE*Math.sin(theta)));
  return points(x,y,theta,"swing");
}

function knee(a,z,upper,lower,side=1) {
  const dx=z[0]-a[0],dy=z[1]-a[1],d=Math.max(.001,Math.hypot(dx,dy));
  const length=clamp(d,Math.abs(upper-lower)+.002,upper+lower-.002);
  const c=(upper*upper-lower*lower+length*length)/(2*length);
  const h=Math.sqrt(Math.max(0,upper*upper-c*c))*side;
  return [a[0]+(dx*c+dy*h)/d,a[1]+(dy*c-dx*h)/d];
}

function walkState(t,kind="wake") {
  const seq=modes[kind];
  let i=0;
  while(i+1<seq.length-1&&t>=seq[i+1].t)i++;
  const a=seq[i],next=seq[i+1],p=clamp((t-a.t)/(next.t-a.t));
  const root=mix(a.x,next.x,p)-15;
  const drop=2.6*Math.sin(pi*p)**2;
  const contact=seq.filter((_,n)=>n%2===0);
  const other=seq.filter((_,n)=>n%2===1);
  const near=foot(t,contact,0),far=foot(t,other,-7);
  return {hip:[root,-103-drop],near,far,swing:Math.sin(pi*(i+p))*12,
    angular:.030*Math.sin(pi*(i+p)*2),contact:[near.mode,far.mode]};
}

function createCast(b) {
  const {at,path,stroke,line,ell,gradient,halo}=b;
  const tones={light:"#394a54",shade:"#1c2b36",rim:"#73838a",hair:"#08151f",skin:"#505958",near:"#293b48",far:"#172735"};

  function head(cx,cy,s,angle=0,look=0,mouth=0,lit=.4,other=false) {
    at(cx,cy,s,s,angle,()=>{
      const shadow=other?"#18252c":"#1b2933";
      const mid=other?"#35413f":"#2e3f47";
      const edge=other?"#56625b":"#4d616b";
      path("M-12 8 L11 12 L10 29 Q3 36 -15 33 Q-11 21 -12 8Z",
        gradient(-13,16,11,31,[[0,shadow],[.70,mid],[1,"#4c585b"]]));
      path("M-18 -11 C-17 -21 -9 -25 -1 -24 Q10 -23 15 -17 Q17 -12 16 -8 L17 -3 L20.5 4 Q21.7 6 18.6 7 L17 7 L17 12 Q16 17 10 19 Q4 21 -1 17 L-11 13 Q-17 9 -19 3Z",
        gradient(-19,-15,21,17,[[0,shadow],[.64,mid],[1,edge]]));
      path("M-17 8 C-22 -5 -22 -15 -16 -22 Q-7 -30 7 -26 Q15 -24 19 -18 L15 -16 Q6 -21 -1 -17 Q-8 -13 -10 -4 L-13 0 L-15 8Z",
        other?"#18242b":tones.hair);
      stroke("M-19 -12 Q-15 -25 -.5 -26 Q9 -27 15 -22",rgba(152,180,186,.045+lit*.20),.64);
      path("M-14 5 Q-16 -.7 -13 -2 Q-9 -2 -9 2 Q-9 7 -12 8Z",
        rgba(98,116,117,.065+lit*.25));
      line(11.5,-5+look,15.2,-5+look,rgba(9,18,26,.63),.60);
      if(lit>.24)ell(14.1,-3.4+look,.42,.48,rgba(203,225,226,.84*lit));
      stroke("M17 -7 Q17 -1 20.2 4.3 M16.9 10 Q16 16 12.1 18.2",
        rgba(148,169,167,.09+lit*.36),.60);
      if(mouth>0)stroke("M13 10 Q15 "+(9.9+mouth*1.15)+" 17 "+(10+.62*mouth),
        rgba(10,22,27,.72),.83+mouth*.40);
    });
  }

  function sleeve(a,z,wa,wz,color,glint=.26) {
    const dx=z[0]-a[0],dy=z[1]-a[1],length=Math.hypot(dx,dy);
    at(a[0],a[1],1,1,Math.atan2(dy,dx)-pi*.5,()=>{
      const d="M"+(-wa)+" 0 Q"+(-wa)+" "+(-wa*.68)+" 0 "+(-wa*.58)+
        " Q"+wa+" "+(-wa*.56)+" "+wa+" 0 L"+wz+" "+length+
        " Q"+wz+" "+(length+wz*.42)+" 0 "+(length+wz*.46)+
        " Q"+(-wz)+" "+(length+wz*.4)+" "+(-wz)+" "+length+"Z";
      path(d,color);
      stroke("M"+(wa*.80)+" 1 L"+(wz*.75)+" "+(length-1),rgba(155,180,184,glint),.87);
    });
  }

  function clothLeg(hip,ankle,near,bend=1,other=false) {
    const k=knee(hip,ankle,UPPER,LOWER,bend);
    const c=near?(other?"#2a3a3d":"#273a49"):(other?"#19272e":"#192b3a");
    const lite=near?.27:.10;
    sleeve(hip,k,12.1,8.6,c,lite);
    const end=[mix(k[0],ankle[0],.915),mix(k[1],ankle[1],.915)];
    sleeve(k,end,8.8,6.0,c,lite);
    const d=3.2;
    stroke("M"+(end[0]-d)+" "+(end[1]+1)+" q3 1.3 "+(d*2)+" -.4",rgba(120,144,149,near?.38:.17),.85);
    return k;
  }

  function bare(p,near,lit=1) {
    at(p.x,p.y,1,1,p.angle,()=>{
      const mid=near?"#635b50":"#4e4b43", shade=near?"#3c4548":"#303d40";
      path("M1 -17 Q7 -18 12 -16 L12 -10 Q13 -5 17 -5 L22 -4 Q25 -3 25 0 H2 Q-.35 -.45 0 -3 L1.3 -8Z",
        gradient(-1,-16,23,0,[[0,shade],[.64,mid],[1,rgba(151,137,112,lit*.65+.13)]]));
      stroke("M1 0 H24 M19 -2.4 L24 -2.5",rgba(171,153,127,lit*.16+.12),.52);
    });
  }

  function torso(x,y,s,angle=0,lit=.35,other=false) {
    at(x,y,s,s,angle,()=>{
      const left=other?"#1b292f":tones.shade,right=other?"#405157":tones.light;
      path("M-10 -14 Q-15 -15 -20 -9 Q-25 -4 -25 10 L-22 49 Q-15 58 .5 57 L20 51 Q19 36 20 26 Q24 10 16 -3 Q10 -9 8 -13 Q1 -9 -10 -14Z",
        gradient(-18,-13,23,65,[[0,left],[.59,right],[1,other?"#2a383e":"#243745"]]));
      path("M-22 1 Q-18 9 -14 27 L-13 50 Q-21 53 -22 47 L-24 12Z","rgba(7,19,30,.33)");
      stroke("M-11 -13 Q-2 -7 8 -13 M11 -10 Q23 3 21 22",rgba(157,180,180,.15+.28*lit),.89);
      stroke("M-15 50 Q1 54 16 48",rgba(10,26,37,.40),1.07);
    });
  }

  function hand(x,y,s,theta,lit=.5) {
    at(x,y,s,s,theta,()=>{
      path("M-4 -5 Q1 -6 4 -4 L5 0 L9 3 Q10 5 8 6 L5 5 L3 9 Q-1 12 -4 7 Q-6 4 -5 1Z",
        rgba(136,139,123,.35+lit*.48));
    });
  }

  function arms(a,w,lit,near=true,other=false) {
    const e=knee(a,w,31,30,near?-1:1);
    const c=near?(other?"#384948":"#334756"):(other?"#233539":"#203542");
    sleeve(a,e,7.2,5.85,c,near?.21:.10);
    sleeve(e,w,5.8,4.2,c,near?.24:.11);
    hand(w[0],w[1],.78,Math.atan2(w[1]-e[1],w[0]-e[0])-pi*.5,lit);
  }

  function footShadow(p,floor=0) {
    const height=floor-Math.max(p.heel[1],p.toe[1]);
    halo(p.x+9,floor+1,25,3.2,[7,13,15],.60/(1+height*.12));
  }

  function walker(x,y,s,dir,t,kind="wake",pose={}) {
    const {sit=0,reach=0,look=0,light=.44,mouth=0}=pose;
    const state=walkState(t,kind),{near,far,swing,angular}=state;
    const hip=[state.hip[0]-10*sit,state.hip[1]+47*sit];
    const counterSwing=swing*(1-sit);
    at(x,y,s*dir,s,0,()=>{
      footShadow(far,-7);footShadow(near);
      clothLeg([hip[0]-3,hip[1]-3],far.ankle,false);
      bare(far,false,.59);
      const sh=[hip[0]+5-4*sit,hip[1]-50];
      arms([sh[0]+7,sh[1]+8],[hip[0]+15+counterSwing*.91,hip[1]+8],.48,false);
      clothLeg(hip,near.ankle,true);
      bare(near,true,.78);
      torso(sh[0],sh[1],1,angular+.095*sit,light);
      const wrist=[
        mix(hip[0]+5-counterSwing*.95+21*sit,hip[0]+62,reach),
        mix(hip[1]+7+1.2*sit,hip[1]-31,reach)
      ];
      arms([sh[0]-2,sh[1]+8],wrist,.57,true);
      head(sh[0]+2,sh[1]-19,.76,angular+.06*sit,look,mouth,light);
    });
    return state;
  }

  function portrait(x,y,s,dir,opts={}) {
    const {tilt=0,bright=.5,look=0,mouth=0,reach=0,breathe=0}=opts;
    at(x,y,s*dir,s,0,()=>{
      // The close shot and the full figure use this same neck, profile and collar.
      at(-4,22+breathe,1.13,1.15,.07,()=>{
        torso(0,0,1,-.06,bright);
        if(reach>0){
          arms([8,10],[25+27*reach,49-22*reach],bright,true);
        }
      });
      head(0,0,1,tilt,look,mouth,bright);
    });
  }

  function cloaked(x,y,s,angle,loose=0) {
    at(x,y,s,s,angle,()=>{
      const hip=[-3,-77],sh=[0,-129],arm=[14+20*loose,-68+12*loose];
      const ankle1=[10,-8],ankle2=[-9,-11];
      clothLeg([hip[0]-6,hip[1]-5],ankle2,false,1,true);
      clothLeg(hip,ankle1,true,1,true);
      sleeve(ankle1,[24,-5],5.8,4.6,"#182630",.14);
      sleeve(ankle2,[1,-6],5,4,"#14232b",.13);
      torso(sh[0],sh[1],1,.041,.38,true);
      arms([sh[0]-4,sh[1]+13],arm,.35,true,true);
      arms([sh[0]+8,sh[1]+16],[-13,-99+6*loose],.38,false,true);
      head(4,-150,.77,.08,0,0,.36,true);
    });
  }

  const table=[
    [0,508,401, .0,412,420,0],
    [1.18,508,401,-.033,412,420,0],
    [2.74,511,398,-.14,412,430,.94],
    [4.63,514,389,-.24,412,449,1],
    [5.95,520,376,-.38,428,474,1],
    [7.43,523,359,-.57,447,511,.66],
    [8.74,520,341,-1.13,473,511,.31],
    [10.56,517,323,-1.47,489,511,0],
    [11.9,517,324,-1.47,489,511,0],
  ];
  function risePose(t) {
    let i=0;
    while(i+1<table.length-1&&t>table[i+1][0])i++;
    const a=table[i],z=table[i+1],u=ramp(t,a[0],z[0]);
    return a.slice(1).map((v,k)=>mix(v,z[k+1],u));
  }

  function strangerRise(t,floor=424,twitch=0) {
    const [px,py,angle,far,near,grip]=risePose(t);
    const hip=[px,py],sh=[px+49*Math.cos(angle),py+49*Math.sin(angle)];
    const headAt=[sh[0]+19*Math.cos(angle),sh[1]+19*Math.sin(angle)];
    const nearFoot=[near+7,floor-10],farFoot=[far+7,floor-13];
    const arm=(x,y)=>[mix(sh[0]-4,x,grip),Math.min(floor-7,mix(sh[1]+59,y,grip))];
    const bend=mix(-1,1,ramp(t,5.7,9.8));
    halo(px-24,floor-5,97,12,[8,19,21],.55);
    clothLeg([hip[0]-3,hip[1]-4],farFoot,false,bend,true);
    sleeve(farFoot,[far+23,floor-5],5.5,3.9,"#18262d",.12);
    clothLeg(hip,nearFoot,true,bend,true);
    sleeve(nearFoot,[near+23,floor-3],5.5,4.3,"#23333a",.16);
    arms([sh[0]-5,sh[1]+6],arm(548,floor-9),.36,false,true);
    torso(sh[0],sh[1],.94,angle+pi*.5,.41,true);
    const wrist=arm(579,floor-9);
    wrist[0]+=8*twitch; wrist[1]-=8*twitch;
    arms([sh[0]+7,sh[1]+10],wrist,.37,true,true);
    head(headAt[0],headAt[1],.77,angle+pi*.5+.1,0,0,.31,true);
  }

  return {head,portrait,walker,cloaked,strangerRise};
}

module.exports={createCast,walkState,knee,UPPER,LOWER,TOE};
