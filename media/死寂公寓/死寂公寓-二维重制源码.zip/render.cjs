"use strict";

const fs=require("node:fs");
const path=require("node:path");
const {spawn}=require("node:child_process");
const {once}=require("node:events");
const {Readable}=require("node:stream");
const {pipeline}=require("node:stream/promises");
const {createCanvas}=require("./ink.cjs");
const {W,H}=require("./sets.cjs");
const {createFilm}=require("./shots.cjs");
const plan=require("./plan.json");

const preview=path.join(__dirname,"preview");

function stills(){
  const moments=[2.42,5.04,7.76,11.18,14.4,16.12,17.33,18.16,21.22,25.67,26.47,31.34,
    35.86,36.62,41.32,46.70,49.98,52.46,55.56,58.66,64.34,71.54,75.23,84.14,85.66];
  const cols=4,w=256,h=144,row=165,pad=4;
  const sheet=createCanvas(cols*(w+pad)+pad,Math.ceil(moments.length/cols)*row+pad);
  const draw=sheet.getContext("2d"), canvas=createCanvas(W,H), paint=createFilm(canvas);
  draw.fillStyle="#dddcd4";draw.fillRect(0,0,sheet.width,sheet.height);
  draw.font='600 12px "Menlo"';
  fs.mkdirSync(preview,{recursive:true});
  moments.forEach((t,i)=>{
    paint(Math.round(t*plan.fps));
    const x=pad+(i%cols)*(w+pad), y=pad+Math.floor(i/cols)*row;
    draw.drawImage(canvas,x,y,w,h);
    draw.fillStyle="#344449";draw.fillText(t.toFixed(2)+" s",x+5,y+h+14);
    fs.writeFileSync(path.join(preview,"frame-"+i+".png"),canvas.toBuffer("image/png"));
  });
  fs.writeFileSync(path.join(preview,"stills.jpg"),sheet.toBuffer("image/jpeg",94));
}

async function render(){
  const canvas=createCanvas(W*2,H*2), paint=createFilm(canvas);
  const frames=Math.round(plan.duration*plan.fps), output=path.join(__dirname,"picture.mp4");
  const proc=spawn("ffmpeg",[
    "-nostdin","-hide_banner","-loglevel","error","-y",
    "-f","rawvideo","-pix_fmt","rgba","-video_size",canvas.width+"x"+canvas.height,"-framerate",String(plan.fps),
    "-i","pipe:0","-an","-vf","scale=out_color_matrix=bt709:out_range=tv,format=yuv420p",
    "-color_range","tv","-colorspace","bt709","-color_primaries","bt709","-color_trc","bt709",
    "-c:v","libx264","-preset","veryfast","-crf","17","-threads","6","-movflags","+faststart",output
  ],{stdio:["pipe","ignore","inherit"]});
  const ended=once(proc,"exit");
  async function* pictures(){
    for(let frame=0;frame<frames;frame++){
      paint(frame);
      yield canvas.data();
      if(frame>0&&frame%300===0)console.log(frame+"/"+frames);
    }
  }
  try{
    await pipeline(Readable.from(pictures(),{objectMode:false,highWaterMark:65536}),proc.stdin);
    const [code]=await ended;
    if(code)throw new Error("FFmpeg exit "+code);
    console.log(frames+" frames encoded to "+output);
  }catch(error){
    if(proc.exitCode===null)proc.kill();
    throw error;
  }
}

if(process.argv.includes("--stills"))stills();
else render().catch(error=>{console.error(error);process.exitCode=1;});
